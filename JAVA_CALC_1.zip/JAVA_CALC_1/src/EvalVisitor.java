import java.util.HashMap;
import java.util.Map;
import calc.LabeledExprBaseVisitor;
import calc.LabeledExprParser;

public class EvalVisitor extends LabeledExprBaseVisitor<Integer> {
    private final Map<String, Integer> memory = new HashMap<>();

    @Override
    public Integer visitPrintExpr(LabeledExprParser.PrintExprContext ctx) {
        Integer value = visit(ctx.expr());
        System.out.println(value);
        return 0;
    }

    @Override
    public Integer visitAssign(LabeledExprParser.AssignContext ctx) {
        String id = ctx.ID().getText();
        int value = visit(ctx.expr());
        memory.put(id, value);
        return value;
    }

    @Override
    public Integer visitInt(LabeledExprParser.IntContext ctx) {
        return Integer.valueOf(ctx.INT().getText());
    }

    @Override
    public Integer visitId(LabeledExprParser.IdContext ctx) {
        String id = ctx.ID().getText();
        return memory.getOrDefault(id, 0);
    }

    @Override
    public Integer visitParens(LabeledExprParser.ParensContext ctx) {
        return visit(ctx.expr());
    }

    @Override
    public Integer visitMulDiv(LabeledExprParser.MulDivContext ctx) {
        int left = visit(ctx.expr(0));
        int right = visit(ctx.expr(1));
        String op = ctx.op.getText();
        return op.equals("*") ? left * right : left / right; // división entera
    }

    @Override
    public Integer visitAddSub(LabeledExprParser.AddSubContext ctx) {
        int left = visit(ctx.expr(0));
        int right = visit(ctx.expr(1));
        String op = ctx.op.getText();
        return op.equals("+") ? left + right : left - right;
    }

    @Override
    public Integer visitBlank(LabeledExprParser.BlankContext ctx) {
        return 0;
    }
}