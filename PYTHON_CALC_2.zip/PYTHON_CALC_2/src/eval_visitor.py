import sys
import os

# Agregar el directorio raíz al path de Python
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gen.CalcExtVisitor import CalcExtVisitor
import math

class EvalVisitor(CalcExtVisitor):
    # ... (el resto del código permanece igual)
    def __init__(self):
        self.variables = {}
        self.use_degrees = True
    
    def visitPrintExpr(self, ctx):
        value = self.visit(ctx.expr())
        print(f">> {value}")
        return value
    
    # ... (todas las demás funciones igual)    
    def visitAssign(self, ctx):
        id = ctx.ID().getText()
        value = self.visit(ctx.expr())
        self.variables[id] = value
        print(f">> Variable '{id}' = {value}")
        return value
    
    def visitSetDeg(self, ctx):
        self.use_degrees = True
        print(">> Modo grados activado")
        return 0.0
    
    def visitSetRad(self, ctx):
        self.use_degrees = False
        print(">> Modo radianes activado")
        return 0.0
    
    def visitBlank(self, ctx):
        return 0.0
    
    def visitPow(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        return math.pow(left, right)
    
    def visitFact(self, ctx):
        n = int(self.visit(ctx.expr()))
        if n < 0:
            raise Exception("Factorial de negativo no existe")
        if n > 20:
            raise Exception("Número demasiado grande para factorial")
        result = 1
        for i in range(2, n + 1):
            result *= i
        return float(result)
    
    def visitMulDiv(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        op = ctx.op.text
        if op == '*':
            return left * right
        else:
            if right == 0:
                raise Exception("División por cero")
            return left / right
    
    def visitAddSub(self, ctx):
        left = self.visit(ctx.expr(0))
        right = self.visit(ctx.expr(1))
        op = ctx.op.text
        if op == '+':
            return left + right
        else:
            return left - right
    
    def visitFuncCall(self, ctx):
        arg = self.visit(ctx.expr())
        func_name = ctx.func().getText().lower()
        
        value = arg
        if self.use_degrees and func_name not in ['sqrt', 'log', 'ln']:
            value = math.radians(arg)
        
        if func_name == 'sin':
            return math.sin(value)
        elif func_name == 'cos':
            return math.cos(value)
        elif func_name == 'tan':
            if math.cos(value) == 0:
                raise Exception("Tangente indefinida")
            return math.tan(value)
        elif func_name == 'sqrt':
            if arg < 0:
                raise Exception("Raíz cuadrada de negativo")
            return math.sqrt(arg)
        elif func_name == 'ln':
            if arg <= 0:
                raise Exception("Logaritmo natural de número no positivo")
            return math.log(arg)
        elif func_name == 'log':
            if arg <= 0:
                raise Exception("Logaritmo base 10 de número no positivo")
            return math.log10(arg)
        else:
            raise Exception(f"Función no reconocida: {func_name}")
    
    def visitUnaryMinus(self, ctx):
        return -self.visit(ctx.expr())
    
    def visitUnaryPlus(self, ctx):
        return self.visit(ctx.expr())
    
    def visitNumber(self, ctx):
        return float(ctx.NUMBER().getText())
    
    def visitPi(self, ctx):
        return math.pi
    
    def visitConstE(self, ctx):
        return math.e
    
    def visitId(self, ctx):
        id = ctx.ID().getText()
        if id in self.variables:
            return self.variables[id]
        raise Exception(f"Variable no definida: {id}")
    
    def visitParens(self, ctx):
        return self.visit(ctx.expr())