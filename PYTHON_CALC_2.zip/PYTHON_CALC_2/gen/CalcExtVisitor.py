# Generated from grammar/CalcExt.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .CalcExtParser import CalcExtParser
else:
    from CalcExtParser import CalcExtParser

# This class defines a complete generic visitor for a parse tree produced by CalcExtParser.

class CalcExtVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by CalcExtParser#prog.
    def visitProg(self, ctx:CalcExtParser.ProgContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#printExpr.
    def visitPrintExpr(self, ctx:CalcExtParser.PrintExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#assign.
    def visitAssign(self, ctx:CalcExtParser.AssignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#setDeg.
    def visitSetDeg(self, ctx:CalcExtParser.SetDegContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#setRad.
    def visitSetRad(self, ctx:CalcExtParser.SetRadContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#blank.
    def visitBlank(self, ctx:CalcExtParser.BlankContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#end.
    def visitEnd(self, ctx:CalcExtParser.EndContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#FuncCall.
    def visitFuncCall(self, ctx:CalcExtParser.FuncCallContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#Number.
    def visitNumber(self, ctx:CalcExtParser.NumberContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#MulDiv.
    def visitMulDiv(self, ctx:CalcExtParser.MulDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#AddSub.
    def visitAddSub(self, ctx:CalcExtParser.AddSubContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#ConstE.
    def visitConstE(self, ctx:CalcExtParser.ConstEContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#Parens.
    def visitParens(self, ctx:CalcExtParser.ParensContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#UnaryPlus.
    def visitUnaryPlus(self, ctx:CalcExtParser.UnaryPlusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#Pi.
    def visitPi(self, ctx:CalcExtParser.PiContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#Pow.
    def visitPow(self, ctx:CalcExtParser.PowContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#UnaryMinus.
    def visitUnaryMinus(self, ctx:CalcExtParser.UnaryMinusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#Id.
    def visitId(self, ctx:CalcExtParser.IdContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#Fact.
    def visitFact(self, ctx:CalcExtParser.FactContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CalcExtParser#func.
    def visitFunc(self, ctx:CalcExtParser.FuncContext):
        return self.visitChildren(ctx)



del CalcExtParser