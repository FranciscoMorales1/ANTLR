import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Calculadora Extendida - Escribe expresiones o 'exit' para salir");
            System.out.println("Ejemplos: 2+3*4; sin(90); deg; rad; x=5; x*2;");
            System.out.println("==============================================");
            
            // Crear el input stream desde la entrada estándar
            CharStream input = CharStreams.fromStream(System.in);
            
            // Crear el lexer
            CalcExtLexer lexer = new CalcExtLexer(input);
            
            // Crear el stream de tokens
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            
            // Crear el parser
            CalcExtParser parser = new CalcExtParser(tokens);
            
            // Parsear la regla inicial 'prog'
            ParseTree tree = parser.prog();
            
            // Crear y ejecutar el visitor
            EvalVisitor eval = new EvalVisitor();
            eval.visit(tree);
            
        } catch (IOException e) {
            System.err.println("Error de entrada/salida: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}