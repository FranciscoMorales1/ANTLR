# Generated from grammar/CalcExt.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,24,73,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,1,0,4,0,12,8,0,
        11,0,12,0,13,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,3,1,31,8,1,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,
        3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,53,8,3,1,3,1,3,1,3,1,3,1,3,
        1,3,1,3,1,3,1,3,1,3,1,3,5,3,66,8,3,10,3,12,3,69,9,3,1,4,1,4,1,4,
        0,1,6,5,0,2,4,6,8,0,4,2,0,2,2,23,23,1,0,5,6,1,0,7,8,1,0,11,16,83,
        0,11,1,0,0,0,2,30,1,0,0,0,4,32,1,0,0,0,6,52,1,0,0,0,8,70,1,0,0,0,
        10,12,3,2,1,0,11,10,1,0,0,0,12,13,1,0,0,0,13,11,1,0,0,0,13,14,1,
        0,0,0,14,15,1,0,0,0,15,16,5,0,0,1,16,1,1,0,0,0,17,18,3,6,3,0,18,
        19,3,4,2,0,19,31,1,0,0,0,20,21,5,21,0,0,21,22,5,1,0,0,22,23,3,6,
        3,0,23,24,3,4,2,0,24,31,1,0,0,0,25,26,5,17,0,0,26,31,3,4,2,0,27,
        28,5,18,0,0,28,31,3,4,2,0,29,31,3,4,2,0,30,17,1,0,0,0,30,20,1,0,
        0,0,30,25,1,0,0,0,30,27,1,0,0,0,30,29,1,0,0,0,31,3,1,0,0,0,32,33,
        7,0,0,0,33,5,1,0,0,0,34,35,6,3,-1,0,35,36,3,8,4,0,36,37,5,9,0,0,
        37,38,3,6,3,0,38,39,5,10,0,0,39,53,1,0,0,0,40,41,5,8,0,0,41,53,3,
        6,3,7,42,43,5,7,0,0,43,53,3,6,3,6,44,53,5,22,0,0,45,53,5,19,0,0,
        46,53,5,20,0,0,47,53,5,21,0,0,48,49,5,9,0,0,49,50,3,6,3,0,50,51,
        5,10,0,0,51,53,1,0,0,0,52,34,1,0,0,0,52,40,1,0,0,0,52,42,1,0,0,0,
        52,44,1,0,0,0,52,45,1,0,0,0,52,46,1,0,0,0,52,47,1,0,0,0,52,48,1,
        0,0,0,53,67,1,0,0,0,54,55,10,12,0,0,55,56,5,3,0,0,56,66,3,6,3,12,
        57,58,10,10,0,0,58,59,7,1,0,0,59,66,3,6,3,11,60,61,10,9,0,0,61,62,
        7,2,0,0,62,66,3,6,3,10,63,64,10,11,0,0,64,66,5,4,0,0,65,54,1,0,0,
        0,65,57,1,0,0,0,65,60,1,0,0,0,65,63,1,0,0,0,66,69,1,0,0,0,67,65,
        1,0,0,0,67,68,1,0,0,0,68,7,1,0,0,0,69,67,1,0,0,0,70,71,7,3,0,0,71,
        9,1,0,0,0,5,13,30,52,65,67
    ]

class CalcExtParser ( Parser ):

    grammarFileName = "CalcExt.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "';'", "'^'", "'!'", "'*'", "'/'", 
                     "'+'", "'-'", "'('", "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "SIN", "COS", 
                      "TAN", "SQRT", "LN", "LOG", "DEG", "RAD", "PI", "E", 
                      "ID", "NUMBER", "NEWLINE", "WS" ]

    RULE_prog = 0
    RULE_stat = 1
    RULE_end = 2
    RULE_expr = 3
    RULE_func = 4

    ruleNames =  [ "prog", "stat", "end", "expr", "func" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    SIN=11
    COS=12
    TAN=13
    SQRT=14
    LN=15
    LOG=16
    DEG=17
    RAD=18
    PI=19
    E=20
    ID=21
    NUMBER=22
    NEWLINE=23
    WS=24

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CalcExtParser.EOF, 0)

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalcExtParser.StatContext)
            else:
                return self.getTypedRuleContext(CalcExtParser.StatContext,i)


        def getRuleIndex(self):
            return CalcExtParser.RULE_prog

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = CalcExtParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 11 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 10
                self.stat()
                self.state = 13 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 16776068) != 0)):
                    break

            self.state = 15
            self.match(CalcExtParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CalcExtParser.RULE_stat

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class SetRadContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def RAD(self):
            return self.getToken(CalcExtParser.RAD, 0)
        def end(self):
            return self.getTypedRuleContext(CalcExtParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetRad" ):
                return visitor.visitSetRad(self)
            else:
                return visitor.visitChildren(self)


    class BlankContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def end(self):
            return self.getTypedRuleContext(CalcExtParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlank" ):
                return visitor.visitBlank(self)
            else:
                return visitor.visitChildren(self)


    class SetDegContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DEG(self):
            return self.getToken(CalcExtParser.DEG, 0)
        def end(self):
            return self.getTypedRuleContext(CalcExtParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSetDeg" ):
                return visitor.visitSetDeg(self)
            else:
                return visitor.visitChildren(self)


    class PrintExprContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)

        def end(self):
            return self.getTypedRuleContext(CalcExtParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintExpr" ):
                return visitor.visitPrintExpr(self)
            else:
                return visitor.visitChildren(self)


    class AssignContext(StatContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.StatContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(CalcExtParser.ID, 0)
        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)

        def end(self):
            return self.getTypedRuleContext(CalcExtParser.EndContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssign" ):
                return visitor.visitAssign(self)
            else:
                return visitor.visitChildren(self)



    def stat(self):

        localctx = CalcExtParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.state = 30
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = CalcExtParser.PrintExprContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 17
                self.expr(0)
                self.state = 18
                self.end()
                pass

            elif la_ == 2:
                localctx = CalcExtParser.AssignContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 20
                self.match(CalcExtParser.ID)
                self.state = 21
                self.match(CalcExtParser.T__0)
                self.state = 22
                self.expr(0)
                self.state = 23
                self.end()
                pass

            elif la_ == 3:
                localctx = CalcExtParser.SetDegContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 25
                self.match(CalcExtParser.DEG)
                self.state = 26
                self.end()
                pass

            elif la_ == 4:
                localctx = CalcExtParser.SetRadContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 27
                self.match(CalcExtParser.RAD)
                self.state = 28
                self.end()
                pass

            elif la_ == 5:
                localctx = CalcExtParser.BlankContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 29
                self.end()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EndContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(CalcExtParser.NEWLINE, 0)

        def getRuleIndex(self):
            return CalcExtParser.RULE_end

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnd" ):
                return visitor.visitEnd(self)
            else:
                return visitor.visitChildren(self)




    def end(self):

        localctx = CalcExtParser.EndContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_end)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 32
            _la = self._input.LA(1)
            if not(_la==2 or _la==23):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CalcExtParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class FuncCallContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def func(self):
            return self.getTypedRuleContext(CalcExtParser.FuncContext,0)

        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncCall" ):
                return visitor.visitFuncCall(self)
            else:
                return visitor.visitChildren(self)


    class NumberContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMBER(self):
            return self.getToken(CalcExtParser.NUMBER, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)


    class MulDivContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalcExtParser.ExprContext)
            else:
                return self.getTypedRuleContext(CalcExtParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulDiv" ):
                return visitor.visitMulDiv(self)
            else:
                return visitor.visitChildren(self)


    class AddSubContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalcExtParser.ExprContext)
            else:
                return self.getTypedRuleContext(CalcExtParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddSub" ):
                return visitor.visitAddSub(self)
            else:
                return visitor.visitChildren(self)


    class ConstEContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def E(self):
            return self.getToken(CalcExtParser.E, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstE" ):
                return visitor.visitConstE(self)
            else:
                return visitor.visitChildren(self)


    class ParensContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParens" ):
                return visitor.visitParens(self)
            else:
                return visitor.visitChildren(self)


    class UnaryPlusContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryPlus" ):
                return visitor.visitUnaryPlus(self)
            else:
                return visitor.visitChildren(self)


    class PiContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def PI(self):
            return self.getToken(CalcExtParser.PI, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPi" ):
                return visitor.visitPi(self)
            else:
                return visitor.visitChildren(self)


    class PowContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CalcExtParser.ExprContext)
            else:
                return self.getTypedRuleContext(CalcExtParser.ExprContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPow" ):
                return visitor.visitPow(self)
            else:
                return visitor.visitChildren(self)


    class UnaryMinusContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryMinus" ):
                return visitor.visitUnaryMinus(self)
            else:
                return visitor.visitChildren(self)


    class IdContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(CalcExtParser.ID, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitId" ):
                return visitor.visitId(self)
            else:
                return visitor.visitChildren(self)


    class FactContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a CalcExtParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(CalcExtParser.ExprContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFact" ):
                return visitor.visitFact(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = CalcExtParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 6
        self.enterRecursionRule(localctx, 6, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [11, 12, 13, 14, 15, 16]:
                localctx = CalcExtParser.FuncCallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 35
                self.func()
                self.state = 36
                self.match(CalcExtParser.T__8)
                self.state = 37
                self.expr(0)
                self.state = 38
                self.match(CalcExtParser.T__9)
                pass
            elif token in [8]:
                localctx = CalcExtParser.UnaryMinusContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 40
                self.match(CalcExtParser.T__7)
                self.state = 41
                self.expr(7)
                pass
            elif token in [7]:
                localctx = CalcExtParser.UnaryPlusContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 42
                self.match(CalcExtParser.T__6)
                self.state = 43
                self.expr(6)
                pass
            elif token in [22]:
                localctx = CalcExtParser.NumberContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 44
                self.match(CalcExtParser.NUMBER)
                pass
            elif token in [19]:
                localctx = CalcExtParser.PiContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 45
                self.match(CalcExtParser.PI)
                pass
            elif token in [20]:
                localctx = CalcExtParser.ConstEContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 46
                self.match(CalcExtParser.E)
                pass
            elif token in [21]:
                localctx = CalcExtParser.IdContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 47
                self.match(CalcExtParser.ID)
                pass
            elif token in [9]:
                localctx = CalcExtParser.ParensContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 48
                self.match(CalcExtParser.T__8)
                self.state = 49
                self.expr(0)
                self.state = 50
                self.match(CalcExtParser.T__9)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 67
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 65
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                    if la_ == 1:
                        localctx = CalcExtParser.PowContext(self, CalcExtParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 54
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 55
                        self.match(CalcExtParser.T__2)
                        self.state = 56
                        self.expr(12)
                        pass

                    elif la_ == 2:
                        localctx = CalcExtParser.MulDivContext(self, CalcExtParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 57
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 58
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==5 or _la==6):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 59
                        self.expr(11)
                        pass

                    elif la_ == 3:
                        localctx = CalcExtParser.AddSubContext(self, CalcExtParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 60
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 61
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==7 or _la==8):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 62
                        self.expr(10)
                        pass

                    elif la_ == 4:
                        localctx = CalcExtParser.FactContext(self, CalcExtParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 63
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 64
                        self.match(CalcExtParser.T__3)
                        pass

             
                self.state = 69
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class FuncContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SIN(self):
            return self.getToken(CalcExtParser.SIN, 0)

        def COS(self):
            return self.getToken(CalcExtParser.COS, 0)

        def TAN(self):
            return self.getToken(CalcExtParser.TAN, 0)

        def SQRT(self):
            return self.getToken(CalcExtParser.SQRT, 0)

        def LN(self):
            return self.getToken(CalcExtParser.LN, 0)

        def LOG(self):
            return self.getToken(CalcExtParser.LOG, 0)

        def getRuleIndex(self):
            return CalcExtParser.RULE_func

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunc" ):
                return visitor.visitFunc(self)
            else:
                return visitor.visitChildren(self)




    def func(self):

        localctx = CalcExtParser.FuncContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_func)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 129024) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[3] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 11)
         




