import java.util.HashMap;
import java.util.Map;

public class EvalVisitor extends CalcExtBaseVisitor<Double> {
    private Map<String, Double> variables = new HashMap<>();
    private boolean useDegrees = true; // Por defecto en grados

    @Override
    public Double visitPrintExpr(CalcExtParser.PrintExprContext ctx) {
        Double value = visit(ctx.expr());
        System.out.println(">> " + value);
        return value;
    }

    @Override
    public Double visitAssign(CalcExtParser.AssignContext ctx) {
        String id = ctx.ID().getText();
        Double value = visit(ctx.expr());
        variables.put(id, value);
        System.out.println(">> Variable '" + id + "' = " + value);
        return value;
    }

    @Override
    public Double visitSetDeg(CalcExtParser.SetDegContext ctx) {
        useDegrees = true;
        System.out.println(">> Modo grados activado");
        return 0.0;
    }

    @Override
    public Double visitSetRad(CalcExtParser.SetRadContext ctx) {
        useDegrees = false;
        System.out.println(">> Modo radianes activado");
        return 0.0;
    }

    @Override
    public Double visitBlank(CalcExtParser.BlankContext ctx) {
        return 0.0;
    }

    @Override
    public Double visitPow(CalcExtParser.PowContext ctx) {
        double left = visit(ctx.expr(0));
        double right = visit(ctx.expr(1));
        return Math.pow(left, right);
    }

    @Override
    public Double visitFact(CalcExtParser.FactContext ctx) {
        int n = visit(ctx.expr()).intValue();
        if (n < 0) throw new RuntimeException("Factorial de negativo no existe");
        if (n > 20) throw new RuntimeException("Número demasiado grande para factorial");
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return (double) result;
    }

    @Override
    public Double visitMulDiv(CalcExtParser.MulDivContext ctx) {
        double left = visit(ctx.expr(0));
        double right = visit(ctx.expr(1));
        // CORRECCIÓN: Usar getText() en lugar de constantes
        if (ctx.op.getText().equals("*")) {
            return left * right;
        } else {
            if (right == 0) throw new RuntimeException("División por cero");
            return left / right;
        }
    }

    @Override
    public Double visitAddSub(CalcExtParser.AddSubContext ctx) {
        double left = visit(ctx.expr(0));
        double right = visit(ctx.expr(1));
        // CORRECCIÓN: Usar getText() en lugar de constantes
        if (ctx.op.getText().equals("+")) {
            return left + right;
        } else {
            return left - right;
        }
    }

    @Override
    public Double visitFuncCall(CalcExtParser.FuncCallContext ctx) {
        Double arg = visit(ctx.expr());
        String funcName = ctx.func().getText().toLowerCase();
        
        // Convertir a radianes si está en grados (excepto para sqrt, log, ln)
        double value = arg;
        if (useDegrees && !funcName.equals("sqrt") && !funcName.equals("log") && !funcName.equals("ln")) {
            value = Math.toRadians(arg);
        }

        switch (funcName) {
            case "sin": return Math.sin(value);
            case "cos": return Math.cos(value);
            case "tan": 
                if (Math.cos(value) == 0) throw new RuntimeException("Tangente indefinida");
                return Math.tan(value);
            case "sqrt": 
                if (arg < 0) throw new RuntimeException("Raíz cuadrada de negativo");
                return Math.sqrt(arg);
            case "ln": 
                if (arg <= 0) throw new RuntimeException("Logaritmo natural de número no positivo");
                return Math.log(arg);
            case "log": 
                if (arg <= 0) throw new RuntimeException("Logaritmo base 10 de número no positivo");
                return Math.log10(arg);
            default: throw new RuntimeException("Función no reconocida: " + funcName);
        }
    }

    @Override
    public Double visitUnaryMinus(CalcExtParser.UnaryMinusContext ctx) {
        return -visit(ctx.expr());
    }

    @Override
    public Double visitUnaryPlus(CalcExtParser.UnaryPlusContext ctx) {
        return visit(ctx.expr());
    }

    @Override
    public Double visitNumber(CalcExtParser.NumberContext ctx) {
        return Double.parseDouble(ctx.NUMBER().getText());
    }

    @Override
    public Double visitPi(CalcExtParser.PiContext ctx) {
        return Math.PI;
    }

    @Override
    public Double visitConstE(CalcExtParser.ConstEContext ctx) {
        return Math.E;
    }

    @Override
    public Double visitId(CalcExtParser.IdContext ctx) {
        String id = ctx.ID().getText();
        if (variables.containsKey(id)) {
            return variables.get(id);
        }
        throw new RuntimeException("Variable no definida: " + id);
    }

    @Override
    public Double visitParens(CalcExtParser.ParensContext ctx) {
        return visit(ctx.expr());
    }
}