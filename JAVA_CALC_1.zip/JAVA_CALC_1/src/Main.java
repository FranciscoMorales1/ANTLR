import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;
import java.nio.file.Paths;
import calc.LabeledExprLexer;
import calc.LabeledExprParser;

public class Main {
    public static void main(String[] args) throws Exception {
        CharStream input = (args.length > 0)
                ? CharStreams.fromPath(Paths.get(args[0]))
                : CharStreams.fromStream(System.in); // termina con Ctrl+Z y Enter en Windows

        LabeledExprLexer lexer = new LabeledExprLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        LabeledExprParser parser = new LabeledExprParser(tokens);

        ParseTree tree = parser.prog(); // regla inicial
        EvalVisitor eval = new EvalVisitor();
        eval.visit(tree);
    }
}