import sys
import os

# Agregar el directorio raíz al path de Python
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from antlr4 import *
from gen.CalcExtLexer import CalcExtLexer
from gen.CalcExtParser import CalcExtParser
from src.eval_visitor import EvalVisitor

def main():
    print("Calculadora Extendida en Python - Escribe expresiones o CTRL+D para salir")
    print("Ejemplos: 2+3*4; sin(90); deg; rad; x=5; x*2;")
    print("==============================================")
    
    try:
        input_stream = InputStream(sys.stdin.read())
        lexer = CalcExtLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = CalcExtParser(stream)
        tree = parser.prog()
        
        visitor = EvalVisitor()
        visitor.visit(tree)
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()