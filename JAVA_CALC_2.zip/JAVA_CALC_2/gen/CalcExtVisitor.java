// Generated from grammar/CalcExt.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link CalcExtParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface CalcExtVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link CalcExtParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(CalcExtParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by the {@code printExpr}
	 * labeled alternative in {@link CalcExtParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintExpr(CalcExtParser.PrintExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assign}
	 * labeled alternative in {@link CalcExtParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(CalcExtParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by the {@code setDeg}
	 * labeled alternative in {@link CalcExtParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetDeg(CalcExtParser.SetDegContext ctx);
	/**
	 * Visit a parse tree produced by the {@code setRad}
	 * labeled alternative in {@link CalcExtParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSetRad(CalcExtParser.SetRadContext ctx);
	/**
	 * Visit a parse tree produced by the {@code blank}
	 * labeled alternative in {@link CalcExtParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlank(CalcExtParser.BlankContext ctx);
	/**
	 * Visit a parse tree produced by {@link CalcExtParser#end}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnd(CalcExtParser.EndContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FuncCall}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncCall(CalcExtParser.FuncCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Number}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumber(CalcExtParser.NumberContext ctx);
	/**
	 * Visit a parse tree produced by the {@code MulDiv}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulDiv(CalcExtParser.MulDivContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AddSub}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddSub(CalcExtParser.AddSubContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ConstE}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstE(CalcExtParser.ConstEContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Parens}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParens(CalcExtParser.ParensContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryPlus}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryPlus(CalcExtParser.UnaryPlusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Pi}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPi(CalcExtParser.PiContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Pow}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPow(CalcExtParser.PowContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryMinus}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryMinus(CalcExtParser.UnaryMinusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Id}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitId(CalcExtParser.IdContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Fact}
	 * labeled alternative in {@link CalcExtParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFact(CalcExtParser.FactContext ctx);
	/**
	 * Visit a parse tree produced by {@link CalcExtParser#func}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc(CalcExtParser.FuncContext ctx);
}